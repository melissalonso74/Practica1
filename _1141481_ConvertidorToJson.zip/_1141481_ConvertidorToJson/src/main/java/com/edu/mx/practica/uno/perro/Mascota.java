package com.edu.mx.practica.uno.perro;

import lombok.Data;

@Data
public class Mascota {

    private String raza;
    private String nombre;
    private String genero;

    public Mascota (String r, String n, String g){
        this.raza=r;
        this.genero= g;
        this.nombre =n;
    }



}
