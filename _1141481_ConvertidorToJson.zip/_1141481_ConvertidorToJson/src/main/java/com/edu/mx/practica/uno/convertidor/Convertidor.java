package com.edu.mx.practica.uno.convertidor;

import com.google.gson.Gson;
import org.json.JSONObject;
import org.json.XML;
import org.json.*;
//import org.codehaus.jackson.JsonGenerationException;
//import org.codehaus.jackson.map.JsonMappingException;
//import org.codehaus.jackson.map.ObjectMapper;

public class Convertidor {

    /**
     * metodo para convertir a JSON
     *
     * @param clase tetxo en formato clase para converit
     * @return clase convertida a JSON
     */


    public String convertidorClaseToJson(String clase) {
        // Class clase = Class.class.forName("com.edu.mx.practica.uno.convertidor");

        return "";
    }


    /**
     * metodo para convertir XML a JSON
     *
     * @param xml tetxo en formato XML para convertir
     * @return XML convertido a JSON
     */
    public static int PRETTY_PRINT_INDENT_FACTOR = 4;

    public JSONObject convertirXmToJson(String xml) {
        JSONObject resultado = new JSONObject();
        try {
            resultado = XML.toJSONObject(xml);
            //resultado = xmlJSONObj.toString(PRETTY_PRINT_INDENT_FACTOR);
        } catch (JSONException je) {
            System.out.println(je.toString());
        }
        //crear instancia
        //Gson gson = new Gson();
        //se agrega el texto de entrada para convertirlo
        //String resultado=gson.toJson(xml);

        return resultado;
    }


    public String Objecttojson(Object m) {
        Gson gson = new Gson();
        String resultado = gson.toJson(m);
        return resultado;
    }


}

//}
